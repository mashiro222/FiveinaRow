/*
 *  Rapfi, a Gomoku/Renju playing engine supporting piskvork protocol.
 *  Copyright (C) 2022  Rapfi developers
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "../core/pos.h"
#include "../core/types.h"

#include <algorithm>
#include <cctype>
#include <string>
#include <string_view>
#include <vector>

namespace Database {

/// DBLabel represents a one-byte tag that attached to a node in the game DAG.
enum DBLabel : int8_t {
    LABEL_NULL = 0,   /// Null record, default constructed, only stores key in database
    LABEL_NONE = -1,  /// Undetermined result

    LABEL_FORCEMOVE = '!',  /// the forced move (will be used as root move if exist)
    LABEL_WIN       = 'w',  /// a winning position
    LABEL_LOSE      = 'l',  /// a losing position
    LABEL_DRAW      = 'd',  /// a draw position
    LABEL_BLOCKMOVE = 'x',  /// a blocked position (will not be considered in search)
};

/// Return true if the label has a determined result.
constexpr bool isDeterminedLabel(DBLabel label)
{
    return label == LABEL_WIN || label == LABEL_LOSE || label == LABEL_DRAW;
}

/// Labels compare case-insensitively. Note the (unsigned char) casts: DBLabel is
/// signed and LABEL_NONE is negative -- passing a negative value other than EOF
/// to std::tolower is undefined behavior.
inline bool operator==(DBLabel lhs, DBLabel rhs)
{
    return std::tolower((unsigned char)lhs) == std::tolower((unsigned char)rhs);
}
inline bool operator!=(DBLabel lhs, DBLabel rhs)
{
    return !(lhs == rhs);
}

/// DBDepthBound represents two bytes that contain a bound and a depth of one search result.
typedef int16_t DBDepthBound;

/// DBValue represents the (16bit) value from a search result, with the same meaning as Value.
/// A Valid value shoud be in range [-30000, 30000]. Value with absolute numeric that larger
/// than VALUE_MATE_IN_MAX_PLY is consided as a mate value, and steps to mate can be get with
/// mate_step() function.
typedef int16_t DBValue;

/// DBRecordMask specify what parts of a record are selected.
enum DBRecordMask {
    RECORD_MASK_NONE       = 0x0,
    RECORD_MASK_LABEL      = 0x1,
    RECORD_MASK_VALUE      = 0x2,
    RECORD_MASK_DEPTHBOUND = 0x4,
    RECORD_MASK_TEXT       = 0x8,

    RECORD_MASK_LVDB = RECORD_MASK_LABEL | RECORD_MASK_VALUE | RECORD_MASK_DEPTHBOUND,
    RECORD_MASK_ALL  = RECORD_MASK_LVDB | RECORD_MASK_TEXT
};

/// DBRecord contains all the information for one position.
struct DBRecord
{
    /// label ('l' or 'w' or '\0', 1 byte)
    DBLabel label;
    /// value (int16, 2 bytes, optional)
    DBValue value;
    /// depth & bound (int16, 2 bytes, optional)
    DBDepthBound depthbound;
    /// utf-8 text message (string ending with '\0', (n3 - 5) bytes, optional)
    std::string text;

    /// Return the depth component of a depth bound.
    int depth() const { return int(depthbound) >> 2; }
    /// Return the bound component of a depth bound.
    Bound bound() const { return Bound(int(depthbound) & 0b11); }
    /// Set a new depth and bound for this record.
    DBDepthBound setDepthBound(int depth, Bound bound)
    {
        return depthbound = int16_t((depth << 2) | bound);
    }
    /// Checks if this record is a null record
    bool isNull() const { return label == LABEL_NULL; }
    /// Update label, value, depth, bound of this record
    void update(const DBRecord &rhs, DBRecordMask mask)
    {
        if (mask & RECORD_MASK_LABEL)
            label = rhs.label;
        if (mask & RECORD_MASK_VALUE)
            value = rhs.value;
        if (mask & RECORD_MASK_DEPTHBOUND)
            depthbound = rhs.depthbound;
        if (mask & RECORD_MASK_TEXT) {
            text = rhs.text;
            // Make sure text is not saved as null label
            if (label == LABEL_NULL && !text.empty())
                label = LABEL_NONE;
        }
    }
    /// Extract utf-8 comment text from dbRecord.
    std::string comment() const;
    /// Set the utf-8 comment text of this dbRecord.
    void setComment(std::string comment);
    /// Check if this record has any board text.
    bool hasBoardText() const;
    /// Query the utf-8 board text of a canonical pos of this dbRecord.
    std::string boardText(Pos canonicalPos);
    /// Query all existing utf-8 board texts of this dbRecord.
    /// @return The list of all board text views, in forms of (Canonical Pos, Text).
    ///     Note that the returned list is not sorted.
    std::vector<std::pair<Pos, std::string_view>> getAllBoardTexts() const;
    /// Set the utf-8 board text of a canonical pos of this dbRecord.
    void setBoardText(Pos canonicalPos, std::string boardText);
    /// Clear the board text segment of this dbRecord.
    void clearAllBoardText();
    /// Overwrite the board text of this dbRecord from other dbRecord.
    /// @param overwrite Whether to overwrite existing board texts in current record.
    ///     If not, all existing board texts will be kept and only new board texts are saved.
    void copyBoardTextFrom(const DBRecord &rhs, bool overwrite);
    /// Get the display label of this record.
    /// @return The display label of this record, in ASCII characters.
    std::string displayLabel() const;
};

/// The rule to use when a overwrite might occur to a position.
enum class OverwriteRule {
    Disabled,               /// No overwrite is allowed (only null record gets overwritten)
    Always,                 /// Always overwrite
    BetterLabel,            /// Overwrite if new record has better label (more determined result)
    BetterValue,            /// Overwrite if new record has more valuable value
    BetterDepthBound,       /// Better label or better depthbound
    BetterValueDepthBound,  /// Better label or more valuable value or better depthbound
};

}  // namespace Database
